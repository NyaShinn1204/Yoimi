from common import *
from command import *

cli()