[dAnime](https://animestore.docomo.ne.jp/animestore/tp_pc)
[Dmm_tv](https://tv.dmm.com/vod/)
[FOD](https://fod.fujitv.co.jp) On Going

coming fix?
- [abema](https://abema.tv)
- [brainshark](https://brainshark.com)