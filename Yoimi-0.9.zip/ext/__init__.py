"""
Initiate all extension that are available
"""

from ext.abematv import AbemaTV
from ext.gyao import GYAO
from ext.aniplus import Aniplus
from ext.unext import UNext