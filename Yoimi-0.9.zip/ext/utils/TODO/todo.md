U-Next Todo:
- Add Get movie, season image.
- Apply Thumbnail season image.

Dmm-tv Todo:
- Support Adult content.
- Require More Test.

Other Vod Todo:
- Gointg to create danime.

Other Todo:
- Add Download thumbnail
- Add Save Session function
- Fix config.yml
- Add Support Comment Downloader (NCOverlay)