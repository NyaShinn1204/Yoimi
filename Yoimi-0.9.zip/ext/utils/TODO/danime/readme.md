I don't have a danime account and I don't even know how to log in to 2fa bypass.

Waiting until I get it.